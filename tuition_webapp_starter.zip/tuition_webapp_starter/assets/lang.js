
const LANGS = {
  en: {
    brand: "TutorHub",
    login: "Login",
    signup: "Sign up",
    logout: "Logout",
    browse_courses: "Browse Courses",
    my_courses: "My Courses",
    dashboard: "Dashboard",
    teacher_panel: "Teacher Dashboard",
    admin_panel: "Admin",
    search: "Search courses...",
    enroll: "Enroll",
    free: "Free",
    paid: "Paid",
    price: "Price",
    starts_on: "Starts on",
    by: "By",
    upload_materials: "Upload Materials",
    chat: "Chat",
    schedule: "Schedule",
    pay_now: "Pay & Join",
    continue: "Continue",
    course_materials: "Course Materials",
    students: "Students",
    assignments: "Assignments/Quizzes",
    profile: "Profile"
  },
  bn: {
    brand: "টিউটারহাব",
    login: "লগইন",
    signup: "সাইন আপ",
    logout: "লগআউট",
    browse_courses: "কোর্স দেখুন",
    my_courses: "আমার কোর্স",
    dashboard: "ড্যাশবোর্ড",
    teacher_panel: "শিক্ষক ড্যাশবোর্ড",
    admin_panel: "অ্যাডমিন",
    search: "কোর্স খুঁজুন...",
    enroll: "ভর্তি",
    free: "ফ্রি",
    paid: "পেইড",
    price: "দাম",
    starts_on: "শুরুর তারিখ",
    by: "শিক্ষক",
    upload_materials: "মেটেরিয়াল আপলোড",
    chat: "চ্যাট",
    schedule: "ক্লাস সূচি",
    pay_now: "পে করে যোগ দিন",
    continue: "চালিয়ে যান",
    course_materials: "কোর্স মেটেরিয়াল",
    students: "শিক্ষার্থীরা",
    assignments: "অ্যাসাইনমেন্ট/কুইজ",
    profile: "প্রোফাইল"
  }
};
function setLang(lang){
  localStorage.setItem("lang",lang);
  applyLang();
}
function t(key){
  const lang = localStorage.getItem("lang")||"en";
  return (LANGS[lang]&&LANGS[lang][key])||key;
}
function applyLang(){
  document.querySelectorAll("[data-t]").forEach(el=>{
    el.innerText = t(el.dataset.t);
  });
  document.querySelectorAll("[data-ph]").forEach(el=>{
    el.placeholder = t(el.dataset.ph);
  });
}
document.addEventListener("DOMContentLoaded", applyLang);
