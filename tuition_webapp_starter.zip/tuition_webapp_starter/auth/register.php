<?php require_once __DIR__.'/../config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = $_POST['name']; $email = $_POST['email']; $phone = $_POST['phone'];
  $class = $_POST['class_level']; $role = $_POST['role'] ?? 'student';
  $pass = $_POST['password']; $photo = null;
  if(isset($_FILES['photo']) && $_FILES['photo']['size']>0){
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $photo = '/uploads/'.time().'_'.rand(1000,9999).'.'.$ext;
    @mkdir(__DIR__.'/../uploads',0777,true);
    move_uploaded_file($_FILES['photo']['tmp_name'], __DIR__.'/..'.$photo);
  }
  $hash = password_hash($pass, PASSWORD_BCRYPT);
  $otp = rand(100000,999999);
  $stmt = $con->prepare("INSERT INTO users (name,email,phone,class_level,photo,password_hash,role,otp_code) VALUES (?,?,?,?,?,?,?,?)");
  $stmt->bind_param("ssssssss",$name,$email,$phone,$class,$photo,$hash,$role,$otp);
  if($stmt->execute()){
    $_SESSION['pending_email']=$email;
    $msg="Use OTP: ".$otp." to verify. (Demo: shown here since email/SMS not configured.)";
    echo "<script>alert('".$msg."');location.href='/auth/verify.php';</script>";
    exit;
  } else { $err="Registration failed: ".$con->error; }
}
?>
<?php include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Sign up</h2>
  <?php if(isset($err)) echo "<div class='alert alert-error'>".e($err)."</div>"; ?>
  <form method="post" enctype="multipart/form-data" class="grid">
    <input class="input" name="name" placeholder="Full name" required>
    <input class="input" name="email" type="email" placeholder="Email" required>
    <input class="input" name="phone" placeholder="Phone" required>
    <input class="input" name="class_level" placeholder="Class (mandatory)" required>
    <input class="input" name="password" type="password" placeholder="Password" required>
    <div>
      <label>Photo</label>
      <input class="input" type="file" name="photo" accept="image/*">
    </div>
    <div>
      <label>Role</label>
      <select class="input" name="role">
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
    </div>
    <button class="btn btn-primary">Create account</button>
  </form>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
