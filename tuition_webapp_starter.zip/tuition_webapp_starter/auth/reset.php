<?php require_once __DIR__.'/../config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email = $_POST['email']; $otp = rand(100000,999999);
  $stmt = $con->prepare("UPDATE users SET otp_code=? WHERE email=?");
  $stmt->bind_param("ss",$otp,$email); $stmt->execute();
  $msg="Use OTP: ".$otp." to reset password. (Demo only)";
  echo "<script>alert('".$msg."');location.href='/auth/reset_confirm.php?email=".urlencode($email)."';</script>"; exit;
}
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Password reset</h2>
  <form method="post" class="grid">
    <input class="input" type="email" name="email" placeholder="Your email" required>
    <button class="btn btn-primary">Send OTP</button>
  </form>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
