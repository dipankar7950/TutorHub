<?php require_once __DIR__.'/../config.php';
$email = $_GET['email'] ?? '';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=$_POST['email']; $otp=$_POST['otp']; $new=$_POST['password'];
  $stmt=$con->prepare("SELECT id FROM users WHERE email=? AND otp_code=?");
  $stmt->bind_param("ss",$email,$otp); $stmt->execute(); $res=$stmt->get_result();
  if($u=$res->fetch_assoc()){
    $hash=password_hash($new,PASSWORD_BCRYPT);
    $upd=$con->prepare("UPDATE users SET password_hash=?, otp_code=NULL WHERE id=?");
    $upd->bind_param("si",$hash,$u['id']); $upd->execute();
    echo "<script>alert('Password updated');location.href='/auth/login.php';</script>"; exit;
  } else { $err="Invalid OTP"; }
}
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Reset password</h2>
  <?php if(isset($err)) echo "<div class='alert alert-error'>".e($err)."</div>"; ?>
  <form method="post" class="grid">
    <input class="input" name="email" placeholder="Email" value="<?php echo e($email); ?>" required>
    <input class="input" name="otp" placeholder="OTP" required>
    <input class="input" type="password" name="password" placeholder="New password" required>
    <button class="btn btn-primary">Update</button>
  </form>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
