<?php require_once __DIR__.'/../config.php';
if(!isset($_SESSION['pending_email'])){ redirect('/auth/login.php'); }
$email = $_SESSION['pending_email'];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $otp = $_POST['otp'];
  $stmt = $con->prepare("UPDATE users SET verified=1 WHERE email=? AND otp_code=?");
  $stmt->bind_param("ss", $email, $otp);
  $stmt->execute();
  if($stmt->affected_rows>0){
    unset($_SESSION['pending_email']);
    echo "<script>alert('Verified! Please login');location.href='/auth/login.php';</script>"; exit;
  } else { $err="Invalid OTP"; }
}
?>
<?php include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Verify Account</h2>
  <?php if(isset($err)) echo "<div class='alert alert-error'>".e($err)."</div>"; ?>
  <form method="post" class="grid">
    <input class="input" name="otp" placeholder="Enter OTP" required>
    <button class="btn btn-primary">Verify</button>
  </form>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
