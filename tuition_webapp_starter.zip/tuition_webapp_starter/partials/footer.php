
<footer class="container">
  <div class="card">
    <div class="flex">
      <div>© 2025 TutorHub • 🧡 Learn with dignity • 🌐 বাংলা / English • 🙂✨</div>
      <div><a href="/privacy.html">Privacy</a> • <a href="/terms.html">Terms</a></div>
    </div>
  </div>
</footer>
<script>applyLang()</script>
</body></html>
