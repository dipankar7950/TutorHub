<?php require_once __DIR__.'/../config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TutorHub</title>
<link rel="stylesheet" href="/assets/style.css">
<script src="/assets/lang.js"></script>
</head>
<body>
<div class="container">
  <div class="nav card">
    <div class="flex">
      <div class="brand">🎓 <span data-t="brand">TutorHub</span></div>
      <div class="lang-switch">
        <button class="btn" onclick="setLang('en')">EN</button>
        <button class="btn" onclick="setLang('bn')">বাংলা</button>
      </div>
    </div>
    <div class="flex">
      <a href="/index.php" class="btn"><span data-t="browse_courses">Browse Courses</span></a>
      <?php if(is_logged_in()){ ?>
        <a href="/dashboard.php" class="btn"><span data-t="dashboard">Dashboard</span></a>
        <a href="/auth/logout.php" class="btn"><span data-t="logout">Logout</span></a>
      <?php } else { ?>
        <a href="/auth/login.php" class="btn"><span data-t="login">Login</span></a>
        <a href="/auth/register.php" class="btn btn-primary"><span data-t="signup">Sign up</span></a>
      <?php } ?>
    </div>
  </div>
