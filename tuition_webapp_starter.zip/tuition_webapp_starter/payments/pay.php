<?php require_once __DIR__.'/../config.php'; if(!is_logged_in()) redirect('/auth/login.php');
$enroll_id=intval($_GET['enrollment_id'] ?? 0);
$en=$con->query("SELECT e.*, c.title, c.price FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.id=$enroll_id")->fetch_assoc();
if(!$en){ die('Invalid'); }
$amount = number_format($en['price'], 2, '.', '');
$upi_id = 'raju-pramanick@ybl';
$pn = 'TutorHub';
$tn = rawurlencode('Course '+$en['title']);
$upi_uri = "upi://pay?pa={$upi_id}&pn=".urlencode($pn)."&am={$amount}&cu=INR&tn=".urlencode($en['title'])."&tr=ENR".$enroll_id."U".user()['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $txn = $_POST['txn_id'];
  $stmt=$con->prepare("UPDATE payments SET status='paid', upi_txn_id=? WHERE enrollment_id=?");
  $stmt->bind_param("si",$txn,$enroll_id); $stmt->execute();
  $con->query("UPDATE enrollments SET paid=1 WHERE id=$enroll_id");
  echo "<script>alert('Payment marked PAID. Admin may verify later.');location.href='/course.php?id=".$en['course_id']."';</script>"; exit;
}
include __DIR__.'/../partials/header.php'; ?>
<div class="grid grid-2">
  <div class="card">
    <h2>Pay & Join</h2>
    <p>Course: <b><?php echo e($en['title']); ?></b></p>
    <p>Amount: <b><?php echo e($amount); ?> INR</b></p>
    <div id="qrcode" class="card"></div>
    <script src="/assets/qrcode.min.js"></script>
    <script>
      const upi = <?php echo json_encode($upi_uri); ?>;
      new QRCode(document.getElementById('qrcode')).makeCode(upi);
    </script>
    <div class="notice">Scan with your UPI app (e.g., PhonePe, GPay, BHIM) to pay to <b><?php echo e($upi_id); ?></b>.</div>
  </div>
  <div class="card">
    <h3>Enter Transaction ID</h3>
    <form method="post" class="grid">
      <input class="input" name="txn_id" placeholder="UPI Transaction ID / UTR" required>
      <button class="btn btn-primary">Mark as Paid</button>
    </form>
    <small class="muted">Admin/Teacher can verify the UTR and revoke if invalid.</small>
  </div>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
