<?php require_once __DIR__.'/../config.php'; if(!is_logged_in()) redirect('/auth/login.php');
$uid=user()['id']; $res=$con->query("SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE e.student_id=$uid ORDER BY e.joined_at DESC");
include __DIR__.'/../partials/header.php'; ?>
<div class="card"><h2>My Courses</h2></div>
<div class="grid grid-2">
<?php while($c=$res->fetch_assoc()){ ?>
  <div class="card">
    <h3><?php echo e($c['title']); ?></h3>
    <a class="btn btn-primary" href="/course.php?id=<?php echo $c['id']; ?>">Open</a>
  </div>
<?php } ?>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
