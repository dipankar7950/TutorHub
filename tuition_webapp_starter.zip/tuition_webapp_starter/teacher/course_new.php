<?php require_once __DIR__.'/../config.php'; if(!is_teacher()) redirect('/auth/login.php');
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title=$_POST['title']; $desc=$_POST['description']; $price=floatval($_POST['price']); $is_paid=$price>0?1:0; $start=$_POST['start_date'];
  $thumb=null; if(isset($_FILES['thumb']) && $_FILES['thumb']['size']>0){ $ext=pathinfo($_FILES['thumb']['name'], PATHINFO_EXTENSION); $thumb='/uploads/'.time().'_'.rand(1000,9999).'.'.$ext; @mkdir(__DIR__.'/../uploads',0777,true); move_uploaded_file($_FILES['thumb']['tmp_name'], __DIR__.'/..'.$thumb); }
  $stmt=$con->prepare("INSERT INTO courses (teacher_id,title,description,price,is_paid,thumbnail,start_date) VALUES (?,?,?,?,?,?,?)");
  $tid=user()['id']; $stmt->bind_param("issdiss",$tid,$title,$desc,$price,$is_paid,$thumb,$start);
  if($stmt->execute()){ redirect('/teacher/my_courses.php'); } else { $err=$con->error; }
}
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Create Course</h2>
  <?php if(isset($err)) echo "<div class='alert alert-error'>".e($err)."</div>"; ?>
  <form method="post" enctype="multipart/form-data" class="grid">
    <input class="input" name="title" placeholder="Title" required>
    <textarea class="input" name="description" placeholder="Description"></textarea>
    <input class="input" name="price" type="number" step="0.01" placeholder="Price INR (0 for free)" required>
    <input class="input" name="start_date" type="date" required>
    <div><label>Thumbnail</label><input class="input" type="file" name="thumb" accept="image/*"></div>
    <button class="btn btn-primary">Create</button>
  </form>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
