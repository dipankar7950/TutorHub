<?php require_once __DIR__.'/../config.php'; if(!is_teacher()) redirect('/auth/login.php');
$tid=user()['id']; $res=$con->query("SELECT * FROM courses WHERE teacher_id=$tid ORDER BY created_at DESC");
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>My Courses</h2>
  <a class="btn btn-primary" href="/teacher/course_new.php">+ New</a>
</div>
<div class="grid grid-2">
<?php while($c=$res->fetch_assoc()){ ?>
  <div class="card">
    <h3><?php echo e($c['title']); ?></h3>
    <div class="flex">
      <a class="btn" href="/teacher/upload.php?course_id=<?php echo $c['id']; ?>">Upload Materials</a>
      <a class="btn" href="/teacher/schedule.php?course_id=<?php echo $c['id']; ?>">Schedule Live</a>
      <a class="btn btn-danger" href="/teacher/remove.php?id=<?php echo $c['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
    </div>
    <div><a class="btn" href="/course.php?id=<?php echo $c['id']; ?>">Open</a></div>
  </div>
<?php } ?>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
