<?php require_once __DIR__.'/../config.php'; if(!is_teacher()) redirect('/auth/login.php');
$id=intval($_GET['id']??0); $tid=user()['id']; $con->query("DELETE FROM courses WHERE id=$id AND teacher_id=$tid"); redirect('/teacher/my_courses.php');
