<?php require_once __DIR__.'/../config.php'; if(!is_teacher()) redirect('/auth/login.php');
$cid=intval($_GET['course_id']??0);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title=$_POST['title']; $start=$_POST['start_time']; $link=$_POST['meet_link'];
  $stmt=$con->prepare("INSERT INTO live_classes (course_id,title,start_time,meet_link) VALUES (?,?,?,?)");
  $stmt->bind_param("isss",$cid,$title,$start,$link); $stmt->execute();
  echo "<script>alert('Scheduled');location.href='/teacher/schedule.php?course_id=$cid';</script>"; exit;
}
$res=$con->query("SELECT * FROM live_classes WHERE course_id=$cid ORDER BY start_time DESC");
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Schedule Live Class</h2>
  <form method="post" class="grid">
    <input class="input" name="title" placeholder="Title" required>
    <input class="input" type="datetime-local" name="start_time" required>
    <input class="input" name="meet_link" placeholder="Meet/Zoom link" required>
    <button class="btn btn-primary">Add</button>
  </form>
</div>
<div class="card">
  <h3>Upcoming/Recorded</h3>
  <table class="table">
    <tr><th>Title</th><th>Start</th><th>Link</th></tr>
    <?php while($row=$res->fetch_assoc()){ echo "<tr><td>".e($row['title'])."</td><td>".e($row['start_time'])."</td><td><a href='".e($row['meet_link'])."' target='_blank'>Join</a></td></tr>"; } ?>
  </table>
</div>
<?php include __DIR__.'/../partials/footer.php'; ?>
