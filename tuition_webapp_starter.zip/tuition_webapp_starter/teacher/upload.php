<?php require_once __DIR__.'/../config.php'; if(!is_teacher()) redirect('/auth/login.php');
$cid=intval($_GET['course_id']??0);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title=$_POST['title']; $type=$_POST['type']; $content=null; $path=null;
  if($type==='text'){ $content=$_POST['content']; }
  else{
    if(isset($_FILES['file']) && $_FILES['file']['size']>0){
      $ext=pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
      $path='/uploads/'.time().'_'.rand(1000,9999).'.'.$ext; @mkdir(__DIR__.'/../uploads',0777,true);
      move_uploaded_file($_FILES['file']['tmp_name'], __DIR__.'/..'.$path);
    }
  }
  $stmt=$con->prepare("INSERT INTO materials (course_id,title,type,filepath,content) VALUES (?,?,?,?,?)");
  $stmt->bind_param("issss",$cid,$title,$type,$path,$content); $stmt->execute();
  echo "<script>alert('Uploaded');location.href='/teacher/upload.php?course_id=$cid';</script>"; exit;
}
include __DIR__.'/../partials/header.php'; ?>
<div class="card">
  <h2>Upload Materials</h2>
  <form method="post" enctype="multipart/form-data" class="grid">
    <input class="input" name="title" placeholder="Title" required>
    <select class="input" name="type">
      <option value="pdf">PDF</option>
      <option value="video">Video file</option>
      <option value="note">Other file</option>
      <option value="text">Text note</option>
    </select>
    <div id="fileWrap"><input class="input" type="file" name="file"></div>
    <textarea class="input" name="content" id="content" placeholder="Write text (if type is text)" style="display:none"></textarea>
    <button class="btn btn-primary">Upload</button>
  </form>
</div>
<script>
const typeSel=document.querySelector('select[name=type]');
const fileWrap=document.getElementById('fileWrap'); const content=document.getElementById('content');
typeSel.addEventListener('change',()=>{
  if(typeSel.value==='text'){ fileWrap.style.display='none'; content.style.display='block'; }
  else { fileWrap.style.display='block'; content.style.display='none'; }
});
</script>
<?php include __DIR__.'/../partials/footer.php'; ?>
